package controlevendasTeste;


public class Cliente extends Pessoa{
  
}
